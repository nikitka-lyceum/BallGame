using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    [SerializeField] private float _maxX = 2.5f;
    [SerializeField] private Camera _camera;

    private float _xPosition;

    private float _oldMouseX;


    private void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            _oldMouseX = GetWorldMousePosition().x;
        }


        if (Input.GetMouseButton(0))
        {
            float currentMouseX = GetWorldMousePosition().x;
            float delta = currentMouseX - _oldMouseX;
            _oldMouseX = currentMouseX;

            _xPosition -= delta;
            _xPosition = Mathf.Clamp(_xPosition, -_maxX, _maxX);
            transform.position = new Vector3(_xPosition, transform.position.y, 0f);
        }
    }

    private Vector3 GetWorldMousePosition()
    {
        Vector3 mousePosition = Input.mousePosition;
        mousePosition.z = _camera.transform.position.z;

        return _camera.ScreenToWorldPoint(mousePosition);
    }
}
