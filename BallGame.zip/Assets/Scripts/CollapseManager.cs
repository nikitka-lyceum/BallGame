using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CollapseManager : MonoBehaviour
{
    public void Collapse(Ball ballA, Ball ballB)
    {
        if (ballA.isDead == false && ballB.isDead == false)
        {
            if (ballA.Level == ballB.Level)
            {
                ballA.Die();
                ballB.IncreaseLevel();
            }
        }
    }
}
