using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class Ball : MonoBehaviour
{
    public int Level; // 2 4 8 16 32 64 128 / 0 1 2 3 4 5 6 7

    [SerializeField] private Renderer _renderer;
    [SerializeField] private Collider _collider;
    [SerializeField] private Collider _trigger;
    [SerializeField] private TextMeshProUGUI _text;
    [SerializeField] private Rigidbody _rigidbody;


    [SerializeField] private Transform _visualTransform;
    [SerializeField] private BallSettings _ballSettings;

    private CollapseManager _collapseManager;


    public bool isDead = false;

    public void Init(CollapseManager collapseManager)
    {
        _collapseManager = collapseManager;
    }

    public void SetToTube()
    {
        _collider.enabled = false;
        _trigger.enabled = false;
        _rigidbody.isKinematic = true;
    }

    public void Drop()
    {
        _collider.enabled = true;
        _trigger.enabled = true;
        _rigidbody.isKinematic = false;
        _rigidbody.velocity = Vector3.down * 2f;
    }

    [ContextMenu("IncreaseLevel")]
    public void IncreaseLevel()
    {
        SetLevel(Level + 1);
        _trigger.enabled = false;
        _trigger.enabled = true;
    }

    public Material GetMaterial()
    {
        return _renderer.material;
    }

    public Vector3 GetScale()
    {
        return _visualTransform.localScale;
    }

    public void SetLevel(int level)
    {
        Level = level;
        _text.text = Mathf.Pow(2, level + 1).ToString();

        int materialIndex = level % _ballSettings.Materials.Length;

        _renderer.material = _ballSettings.Materials[level];

        float scale = _ballSettings.ScaleCurve.Evaluate(Level);
        _visualTransform.localScale = Vector3.one * scale;
        _collider.transform.localScale = Vector3.one * scale;
        _trigger.transform.localScale = Vector3.one * (scale + 0.1f);
    }

    public void Die()
    {
        isDead = true;
        Destroy(gameObject);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.attachedRigidbody)
        {
            if (other.attachedRigidbody.GetComponent<Ball>() is Ball otherBall)
            {
                _collapseManager.Collapse(this, otherBall);
            }
        }
    }
}
