using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class BallTrail : MonoBehaviour
{
    public int Level; // 2 4 8 16 32 64 128 / 0 1 2 3 4 5 6 7
    public Transform VisualTransform;

    [SerializeField] private Renderer _renderer;
    [SerializeField] private TextMeshProUGUI _text;
    [SerializeField] private BallSettings _ballSettings;


    public void SetLevel(int level)
    {
        Level = level;
        _text.text = Mathf.Pow(2, level + 1).ToString();

        _renderer.material = _ballSettings.MaterialsTrail[level];

        float scale = _ballSettings.ScaleCurve.Evaluate(Level);
        VisualTransform.localScale = Vector3.one * scale;
    }

    public void Die()
    {
        Destroy(gameObject);
    }
}
