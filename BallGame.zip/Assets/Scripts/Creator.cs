using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Creator : MonoBehaviour
{
    [SerializeField] private Transform _tube;
    [SerializeField] private Transform _spawner;
    [SerializeField] private Ball _ballPrefab;
    [SerializeField] private BallTrail _ballTrailPrefab;

    private Ball _ballInTube;
    private Ball _ballInSpawner;


    private BallTrail _ballTrail;
    [SerializeField] private GameObject _cubeTrail;

    [SerializeField] private CollapseManager _collapseManager;

    private void Start()
    {
        CreateBallInTube();
        StartCoroutine(MoveToSpawner());
    }

    private void CreateBallInTube()
    {
        int ballLevel = Random.Range(0, 3); // 0 1 2
        _ballInTube = Instantiate(_ballPrefab, _tube.position, Quaternion.identity);
        _ballInTube.SetLevel(ballLevel);
        _ballInTube.SetToTube();
        _ballInTube.Init(_collapseManager);
    }

    // �������� ���� �� ����� �� ��������
    private IEnumerator MoveToSpawner()
    {
        _ballInTube.transform.parent = _spawner;

        for (float t = 0; t < 1f; t += Time.deltaTime / 0.3f)
        {
            _ballInTube.transform.position = Vector3.Lerp(_tube.position, _spawner.position, t);
            yield return null;
        }

        _ballInTube.transform.localPosition = Vector3.zero;
        _ballInSpawner = _ballInTube;
        _ballInTube = null;
        CreateBallInTube();
    }

    private void Update()
    {
        if (_ballInSpawner)
        {
            if (Input.GetMouseButton(0))
            {
                Ray ray = new Ray(_ballInSpawner.transform.position, _ballInSpawner.transform.up * -100f);

                RaycastHit hit;
                if (_ballTrail is null)
                {
                    _ballTrail = Instantiate(_ballTrailPrefab);
                    _ballTrail.SetLevel(_ballInSpawner.Level);
                }

                else if (Physics.Raycast(ray, out hit))
                {
                    _ballTrail.transform.position = new Vector3(hit.point.x, hit.point.y + (_ballTrail.VisualTransform.localScale.y / 2.5f), hit.point.z);
                    _cubeTrail.transform.position = new Vector3(
                        hit.point.x,
                        (_ballInSpawner.transform.position.y + hit.point.y) / 2,
                        hit.point.z
                    );

                    _cubeTrail.transform.localScale = new Vector3(
                        _ballInSpawner.GetScale().x,
                        _ballInSpawner.transform.position.y - hit.point.y,
                        _cubeTrail.transform.localScale.z
                    );

                    _cubeTrail.GetComponent<Renderer>().material.color = _ballInSpawner.GetMaterial().color;
                }
            }

            if (Input.GetMouseButtonUp(0))
            {
                Drop();
            }
        }
    }

    private void Drop()
    {
        _ballInSpawner.transform.parent = null;
        _ballInSpawner.Drop();
        // ����� ������� ��� ������ ���� ��� �������� ���
        _ballInSpawner = null;

        _ballTrail.Die();
        _ballTrail = null;

        _cubeTrail.transform.localScale = new Vector3(_cubeTrail.transform.localScale.x, 0, _cubeTrail.transform.localScale.z);

        if (_ballInTube)
        {
            StartCoroutine(MoveToSpawner());
        }
    }
}
